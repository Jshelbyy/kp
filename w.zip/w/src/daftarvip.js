const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 10 > Acessar recursos ViP
-Rp. 20 > Recursos VIP + Insira o bot no seu grupo(PAGAMENTO MENSAL!)

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me/553388198621 ou digite *${prefix}owner*_

*NOTA*

*${prefix}bot :*
Para alugar um bot para voce e seus grupos`
}
exports.daftarvip = daftarvip