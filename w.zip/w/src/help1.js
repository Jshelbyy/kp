const help1 = (prefix) => {
	return `
┃MENU EM ATUALIZAÇÃO ⚠️
┣QUALQUER COISA
┣CHAME O DONO
┣wa.me/+553388198621`
}
exports.help1 = help1

