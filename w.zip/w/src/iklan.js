const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 20/ GRUPO (MÊS)*
╠➥ *CRIAR: 60(PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *MERCADO PAGO, BOLETO,PIX*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/3388198621*
║
╚═〘𝑩𝒐𝒕 𝑺𝒉𝒆𝒍𝒃𝒚〙
`
}
exports.iklan = iklan